const express = require('express');
const router = express.Router();
const {
  getTasks,
  getTaskById,
  createTask,
  updateProgress,
  trackTime,
  updateDeadline,
  deleteTask
} = require('../controllers/taskController');
const { protect, leaderOnly } = require('../middleware/auth');

/**
 * @swagger
 * /api/tasks:
 *   get:
 *     summary: Get all tasks
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of tasks
 */
router.get('/', protect, getTasks);

/**
 * @swagger
 * /api/tasks/{id}:
 *   get:
 *     summary: Get task by ID
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Task details
 */
router.get('/:id', protect, getTaskById);

/**
 * @swagger
 * /api/tasks:
 *   post:
 *     summary: Create a new task (Leader only)
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *               description:
 *                 type: string
 *               project_id:
 *                 type: integer
 *               assigned_to:
 *                 type: integer
 *               complexity_level:
 *                 type: integer
 *               deadline:
 *                 type: string
 *     responses:
 *       201:
 *         description: Task created
 */
router.post('/', protect, leaderOnly, createTask);

/**
 * @swagger
 * /api/tasks/{id}/progress:
 *   put:
 *     summary: Update task progress
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               progress:
 *                 type: integer
 *     responses:
 *       200:
 *         description: Progress updated
 */
router.put('/:id/progress', protect, updateProgress);

/**
 * @swagger
 * /api/tasks/{id}/time:
 *   put:
 *     summary: Track task time
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               action:
 *                 type: string
 *                 enum: [start, stop]
 *     responses:
 *       200:
 *         description: Time tracked
 */
router.put('/:id/time', protect, trackTime);

/**
 * @swagger
 * /api/tasks/{id}/deadline:
 *   put:
 *     summary: Update task deadline (Leader only)
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               deadline:
 *                 type: string
 *     responses:
 *       200:
 *         description: Deadline updated
 */
router.put('/:id/deadline', protect, leaderOnly, updateDeadline);

/**
 * @swagger
 * /api/tasks/{id}:
 *   delete:
 *     summary: Delete task (Leader only)
 *     tags: [Tasks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Task deleted
 */
router.delete('/:id', protect, leaderOnly, deleteTask);

module.exports = router;