const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

pool.connect()
  .then(() => {
    console.log(' PostgreSQL Connected');
    return pool.query(`
      CREATE TABLE IF NOT EXISTS notifications (
        notification_id SERIAL PRIMARY KEY,
        user_id         INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
        task_id         INTEGER REFERENCES tasks(task_id) ON DELETE SET NULL,
        title           VARCHAR(255) NOT NULL,
        message         TEXT NOT NULL,
        is_read         BOOLEAN DEFAULT FALSE,
        created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
  })
  .then(() => pool.query(`
    ALTER TABLE notifications
    ADD COLUMN IF NOT EXISTS task_id INTEGER REFERENCES tasks(task_id) ON DELETE SET NULL
  `))
  .then(() => console.log('✅ Notifications table ready'))
  .catch((err) => console.error(' DB Error:', err.message));

module.exports = pool;
