import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000'
});


API.interceptors.request.use((req) => {
  const token = localStorage.getItem('token');
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
  return req;
});

// Auth
export const register = (data) => API.post('/api/auth/register', data);
export const login = (data) => API.post('/api/auth/login', data);

// Users
export const getMe = () => API.get('/api/users/me');
export const getAllUsers = () => API.get('/api/users');
export const getMemberTasks = (id) => API.get(`/api/users/${id}/tasks`);

// Projects
export const getProjects = () => API.get('/api/projects');
export const getProjectById = (id) => API.get(`/api/projects/${id}`);
export const createProject = (data) => API.post('/api/projects', data);
export const updateProject = (id, data) => API.put(`/api/projects/${id}`, data);
export const deleteProject = (id) => API.delete(`/api/projects/${id}`);
export const getProjectMembersScore = (id) => API.get(`/api/projects/${id}/members-score`);
export const getProjectTasks = (id) => API.get(`/api/projects/${id}/tasks`);

// Tasks
export const getTasks = () => API.get('/api/tasks');
export const getTaskById = (id) => API.get(`/api/tasks/${id}`);
export const createTask = (data) => API.post('/api/tasks', data);
export const updateProgress = (id, data) => API.put(`/api/tasks/${id}/progress`, data);
export const trackTime = (id, data) => API.put(`/api/tasks/${id}/time`, data);
export const updateDeadline = (id, data) => API.put(`/api/tasks/${id}/deadline`, data);
export const deleteTask = (id) => API.delete(`/api/tasks/${id}`);

// Notifications
export const getMyNotifications = () => API.get('/api/notifications');
export const getUnreadCount = () => API.get('/api/notifications/unread-count');
export const markNotificationRead = (id) => API.put(`/api/notifications/${id}/read`);
export const markAllNotificationsRead = () => API.put('/api/notifications/read-all');
export const getProjectReport = (id) => API.get(`/api/reports/project/${id}`);
export const getMemberReport = (id) => API.get(`/api/reports/member/${id}`);
export const getTeamReport = () => API.get('/api/reports/team');