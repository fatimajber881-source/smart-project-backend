import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  getTasks,
  updateProgress,
  trackTime,
  getMyNotifications,
  getUnreadCount,
  markNotificationRead,
  markAllNotificationsRead
} from '../services/api';

function MemberDashboard() {
  const [tasks, setTasks] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null); // الـ task المفتوح في الـ modal
  const navigate = useNavigate();
  const name = localStorage.getItem('name');

  useEffect(() => {
    loadTasks();
    loadNotifications();
    // poll كل 30 ثانية لجلب notifications جديدة
    const interval = setInterval(loadUnreadCount, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadNotifications = async () => {
    try {
      const res = await getMyNotifications();
      setNotifications(Array.isArray(res.data) ? res.data : []);
      const unread = res.data.filter(n => !n.is_read).length;
      setUnreadCount(unread);
    } catch (err) {
      console.error(err);
    }
  };

  const loadUnreadCount = async () => {
    try {
      const res = await getUnreadCount();
      setUnreadCount(res.data.count);
    } catch (err) {
      console.error(err);
    }
  };

  const handleNotificationClick = async (n) => {
    // علّم كمقروءة
    if (!n.is_read) {
      await handleMarkRead(n.notification_id);
    }
    // إذا عنده task_id افتح الـ task
    if (n.task_id) {
      const task = tasks.find(t => t.task_id === n.task_id);
      if (task) {
        setSelectedTask(task);
        setShowNotifications(false);
      }
    }
  };

  const handleMarkRead = async (id) => {
    try {
      await markNotificationRead(id);
      setNotifications(prev =>
        prev.map(n => n.notification_id === id ? { ...n, is_read: true } : n)
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (err) {
      console.error(err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await markAllNotificationsRead();
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch (err) {
      console.error(err);
    }
  };

  const loadTasks = async () => {
    try {
      const res = await getTasks();
      setTasks(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error(err);
    }
  };

  const handleProgress = async (taskId, progress) => {
    try {
      await updateProgress(taskId, { progress: parseInt(progress) });
      loadTasks();
    } catch (err) {
      alert('Error updating progress');
    }
  };

  const handleTime = async (taskId, action) => {
    try {
      await trackTime(taskId, { action });
      alert(`Time ${action}ed!`);
    } catch (err) {
      alert('Error tracking time');
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <div style={styles.container}>
      {/* Navbar */}
      <div style={styles.navbar}>
        <h2 style={styles.navTitle}>Smart Project</h2>
        <span style={styles.navName}> {name}</span>

        {/* 🔔 Notification Bell */}
        <div style={{ position: 'relative', display: 'inline-block' }}>
          <button
            style={styles.bellBtn}
            onClick={() => {
              setShowNotifications(!showNotifications);
              if (!showNotifications) loadNotifications();
            }}
          >
            🔔
            {unreadCount > 0 && (
              <span style={styles.badge}>{unreadCount}</span>
            )}
          </button>

          {/* Notification Panel */}
          {showNotifications && (
            <div style={styles.notifPanel}>
              <div style={styles.notifHeader}>
                <span style={{ fontWeight: 600 }}>Notifications</span>
                {unreadCount > 0 && (
                  <button style={styles.readAllBtn} onClick={handleMarkAllRead}>
                    Mark all read
                  </button>
                )}
              </div>
              {notifications.length === 0 ? (
                <div style={styles.notifEmpty}>No notifications yet 🎉</div>
              ) : (
                notifications.map(n => (
                  <div
                    key={n.notification_id}
                    style={{
                      ...styles.notifItem,
                      backgroundColor: n.is_read ? '#fafafa' : '#e8f4fd'
                    }}
                    onClick={() => handleNotificationClick(n)}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <span style={{ fontWeight: n.is_read ? 'normal' : 600, fontSize: '13px' }}>
                        {n.title}
                      </span>
                      {!n.is_read && <span style={styles.unreadDot} />}
                    </div>
                    <p style={{ margin: '4px 0 2px', fontSize: '12px', color: '#555' }}>{n.message}</p>
                    <span style={{ fontSize: '11px', color: '#aaa' }}>
                      {new Date(n.created_at).toLocaleString()}
                    </span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        <button style={styles.logoutBtn} onClick={handleLogout}>Logout</button>
      </div>

      <div style={styles.content}>
        <h3>My Tasks</h3>
        {tasks.length === 0 ? (
          <div style={styles.card}>
            <p>No tasks assigned to you yet</p>
          </div>
        ) : (
          tasks.map(t => (
            <div key={t.task_id} style={styles.card}>
              <h4>{t.title}</h4>
              <p>{t.description}</p>
              <p>Complexity: {t.complexity_level}/5</p>
              <p>Deadline: {t.deadline ? new Date(t.deadline).toLocaleDateString() : 'No deadline'}</p>

              {/* Progress */}
              <p>Progress: {t.progress_percentage}%</p>
              <div style={styles.progressBar}>
                <div style={{ ...styles.progress, width: `${t.progress_percentage}%` }} />
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={t.progress_percentage}
                onChange={(e) => handleProgress(t.task_id, e.target.value)}
                style={{ width: '100%', marginTop: '10px' }}
              />

              {/* Time Tracking */}
              <div style={styles.timeButtons}>
                <button
                  style={styles.startBtn}
                  onClick={() => handleTime(t.task_id, 'start')}
                >
                  ▶ Start
                </button>
                <button
                  style={styles.stopBtn}
                  onClick={() => handleTime(t.task_id, 'stop')}
                >
                  ⏹ Stop
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* ── Task Detail Modal ── */}
      {selectedTask && (
        <div style={styles.modalOverlay} onClick={() => setSelectedTask(null)}>
          <div style={styles.modal} onClick={(e) => e.stopPropagation()}>

            {/* Header */}
            <div style={styles.modalHeader}>
              <h3 style={{ margin: 0 }}>📌 {selectedTask.title}</h3>
              <button style={styles.modalClose} onClick={() => setSelectedTask(null)}>✕</button>
            </div>

            {/* Content */}
            <div style={styles.modalBody}>

              {/* Status + Complexity */}
              <div style={{ display: 'flex', gap: '10px', marginBottom: '16px', flexWrap: 'wrap' }}>
                <span style={{
                  ...styles.statusChipLg,
                  backgroundColor: selectedTask.status === 'completed' ? '#4caf50'
                    : selectedTask.status === 'in_progress' ? '#ff9800' : '#9e9e9e'
                }}>
                  {selectedTask.status}
                </span>
                <span style={styles.complexityBadge}>
                  {'⭐'.repeat(selectedTask.complexity_level)} Complexity {selectedTask.complexity_level}/5
                </span>
              </div>

              {/* Description */}
              {selectedTask.description && (
                <div style={styles.modalSection}>
                  <div style={styles.modalLabel}>📝 Description</div>
                  <p style={{ margin: 0, color: '#444', lineHeight: 1.6 }}>{selectedTask.description}</p>
                </div>
              )}

              {/* Deadline */}
              <div style={styles.modalSection}>
                <div style={styles.modalLabel}>📅 Deadline</div>
                <p style={{ margin: 0, color: selectedTask.deadline ? '#333' : '#aaa' }}>
                  {selectedTask.deadline
                    ? new Date(selectedTask.deadline).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
                    : 'No deadline set'}
                </p>
              </div>

              {/* Progress */}
              <div style={styles.modalSection}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={styles.modalLabel}>📊 Progress</span>
                  <span style={{ fontWeight: 700, color: '#1a73e8' }}>{selectedTask.progress_percentage}%</span>
                </div>
                <div style={{ backgroundColor: '#e0e0e0', borderRadius: '8px', height: '10px' }}>
                  <div style={{
                    width: `${selectedTask.progress_percentage}%`,
                    backgroundColor: selectedTask.progress_percentage === 100 ? '#4caf50' : '#1a73e8',
                    height: '10px',
                    borderRadius: '8px',
                    transition: 'width 0.3s'
                  }} />
                </div>
                <input
                  type="range" min="0" max="100"
                  value={selectedTask.progress_percentage}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSelectedTask(prev => ({ ...prev, progress_percentage: parseInt(val) }));
                    handleProgress(selectedTask.task_id, val);
                  }}
                  style={{ width: '100%', marginTop: '10px', accentColor: '#1a73e8' }}
                />
              </div>

              {/* Time Tracking */}
              <div style={styles.modalSection}>
                <div style={styles.modalLabel}>⏱ Time Tracking</div>
                <div style={{ display: 'flex', gap: '10px', marginTop: '8px' }}>
                  <button style={styles.startBtnLg} onClick={() => handleTime(selectedTask.task_id, 'start')}>
                    ▶ Start Timer
                  </button>
                  <button style={styles.stopBtnLg} onClick={() => handleTime(selectedTask.task_id, 'stop')}>
                    ⏹ Stop Timer
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: { fontFamily: 'Arial, sans-serif', minHeight: '100vh', backgroundColor: '#f0f2f5' },
  navbar: { backgroundColor: '#1a73e8', padding: '15px 30px', display: 'flex', alignItems: 'center', gap: '20px' },
  navTitle: { color: 'white', margin: 0 },
  navName: { color: 'white', marginLeft: 'auto' },
  logoutBtn: { backgroundColor: 'white', color: '#1a73e8', border: 'none', padding: '8px 15px', borderRadius: '5px', cursor: 'pointer' },
  bellBtn: { position: 'relative', backgroundColor: 'transparent', border: 'none', fontSize: '22px', cursor: 'pointer', padding: '4px 8px' },
  badge: { position: 'absolute', top: '-4px', right: '-4px', backgroundColor: '#f44336', color: 'white', borderRadius: '50%', fontSize: '10px', minWidth: '16px', height: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px' },
  notifPanel: { position: 'absolute', right: 0, top: '40px', width: '320px', backgroundColor: 'white', borderRadius: '10px', boxShadow: '0 4px 20px rgba(0,0,0,0.15)', zIndex: 1000, maxHeight: '400px', overflowY: 'auto' },
  notifHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderBottom: '1px solid #eee', fontWeight: 600 },
  readAllBtn: { backgroundColor: 'transparent', border: 'none', color: '#1a73e8', cursor: 'pointer', fontSize: '12px' },
  notifItem: { padding: '12px 16px', borderBottom: '1px solid #f5f5f5', cursor: 'pointer', transition: 'background 0.2s' },
  notifEmpty: { padding: '24px', textAlign: 'center', color: '#888', fontSize: '14px' },
  unreadDot: { width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#1a73e8', flexShrink: 0, marginTop: '3px' },
  // Modal styles
  modalOverlay: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' },
  modal: { backgroundColor: 'white', borderRadius: '14px', width: '100%', maxWidth: '560px', maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 10px 40px rgba(0,0,0,0.2)' },
  modalHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 24px', borderBottom: '1px solid #eee', backgroundColor: '#f8f9ff', borderRadius: '14px 14px 0 0' },
  modalClose: { backgroundColor: 'transparent', border: 'none', fontSize: '20px', cursor: 'pointer', color: '#666', padding: '4px 8px', borderRadius: '50%' },
  modalBody: { padding: '24px' },
  modalSection: { marginBottom: '20px', padding: '14px', backgroundColor: '#fafafa', borderRadius: '8px', border: '1px solid #f0f0f0' },
  modalLabel: { fontWeight: 600, color: '#555', marginBottom: '8px', fontSize: '13px', textTransform: 'uppercase', letterSpacing: '0.5px' },
  statusChipLg: { color: 'white', padding: '5px 14px', borderRadius: '20px', fontSize: '13px', fontWeight: 600 },
  complexityBadge: { backgroundColor: '#fff8e1', color: '#f57f17', padding: '5px 12px', borderRadius: '20px', fontSize: '13px', border: '1px solid #ffe082' },
  startBtnLg: { flex: 1, backgroundColor: '#e8f5e9', color: '#2e7d32', border: '1px solid #a5d6a7', padding: '10px', borderRadius: '8px', cursor: 'pointer', fontWeight: 600, fontSize: '14px' },
  stopBtnLg: { flex: 1, backgroundColor: '#fce4ec', color: '#c62828', border: '1px solid #ef9a9a', padding: '10px', borderRadius: '8px', cursor: 'pointer', fontWeight: 600, fontSize: '14px' },
  content: { padding: '30px' },
  card: { backgroundColor: 'white', padding: '20px', borderRadius: '10px', marginBottom: '15px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' },
  progressBar: { backgroundColor: '#e0e0e0', borderRadius: '5px', height: '8px', marginTop: '5px' },
  progress: { backgroundColor: '#1a73e8', height: '8px', borderRadius: '5px' },
  timeButtons: { display: 'flex', gap: '10px', marginTop: '15px' },
  startBtn: { backgroundColor: '#4caf50', color: 'white', border: 'none', padding: '8px 15px', borderRadius: '5px', cursor: 'pointer' },
  stopBtn: { backgroundColor: '#f44336', color: 'white', border: 'none', padding: '8px 15px', borderRadius: '5px', cursor: 'pointer' }
};

export default MemberDashboard;