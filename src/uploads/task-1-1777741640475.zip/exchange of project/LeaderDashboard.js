import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  getProjects,
  createProject,
  updateProject,
  getProjectMembersScore,
  getProjectTasks,
  getTasks,
  createTask,
  getAllUsers,
  getMemberTasks,
  updateDeadline,
  getProjectReport,
  getTeamReport
} from '../services/api';

function LeaderDashboard() {
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [report, setReport] = useState([]);
  const [activeTab, setActiveTab] = useState('projects');
  const [newProject, setNewProject] = useState({ name: '', description: '' });
  const [editingProject, setEditingProject] = useState(null);
  const [memberTasks, setMemberTasks] = useState([]);
  const [conflicts, setConflicts] = useState([]);
  const [projectScores, setProjectScores] = useState({});   // { project_id: [members] }
  const [expandedScores, setExpandedScores] = useState({}); // { project_id: true/false }
  const [expandedTasks, setExpandedTasks] = useState({});   // { project_id: true/false }
  const [projectTasks, setProjectTasks] = useState({});     // { project_id: [tasks] }
  const [projectReport, setProjectReport] = useState(null); // تقرير المشروع المختار
  const [selectedReportProject, setSelectedReportProject] = useState('');
  const [editingDeadline, setEditingDeadline] = useState(null); // { task_id, deadline }
  const [newTask, setNewTask] = useState({
    title: '', description: '', project_id: '', assigned_to: '', complexity_level: 3
  });
  const navigate = useNavigate();
  const name = localStorage.getItem('name');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [p, t, u, r] = await Promise.all([
        getProjects(), getTasks(), getAllUsers(), getTeamReport()
      ]);
      setProjects(p.data);
      setTasks(t.data);
      setUsers(u.data);
      setReport(r.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateProject = async (e) => {
    e.preventDefault();
    try {
      await createProject(newProject);
      setNewProject({ name: '', description: '' });
      loadData();
      alert('Project created!');
    } catch (err) {
      alert('Error creating project');
    }
  };

  const handleCreateTask = async (e) => {
    e.preventDefault();
    try {
      await createTask(newTask);
      setNewTask({ title: '', description: '', project_id: '', assigned_to: '', complexity_level: 3 });
      setMemberTasks([]);
      setConflicts([]);
      loadData();
      alert('Task created!');
    } catch (err) {
      alert('Error creating task');
    }
  };

  const handleMemberSelect = async (memberId) => {
    setNewTask(prev => ({ ...prev, assigned_to: memberId }));
    setMemberTasks([]);
    setConflicts([]);
    if (!memberId) return;
    try {
      const res = await getMemberTasks(memberId);
      const tasks = res.data;
      setMemberTasks(tasks);
      setNewTask(prev => {
        if (prev.deadline) {
          const selected = new Date(prev.deadline).toDateString();
          const conflicting = tasks.filter(t =>
            t.deadline && new Date(t.deadline).toDateString() === selected
          );
          setConflicts(conflicting);
        }
        return prev;
      });
    } catch (err) {
      console.error('Error fetching member tasks', err);
    }
  };

  const handleDeadlineChange = (deadline) => {
    setNewTask({ ...newTask, deadline });
    if (memberTasks.length > 0 && deadline) {
      const selected = new Date(deadline).toDateString();
      const conflicting = memberTasks.filter(t =>
        t.deadline && new Date(t.deadline).toDateString() === selected
      );
      setConflicts(conflicting);
    } else {
      setConflicts([]);
    }
  };

  const handleLoadReport = async (projectId) => {
    if (!projectId) return;
    try {
      const res = await getProjectReport(projectId);
      setProjectReport(res.data);
    } catch (err) {
      alert('Error loading report');
    }
  };

  const handleUpdateDeadline = async (taskId) => {
    if (!editingDeadline || editingDeadline.task_id !== taskId) return;
    try {
      await updateDeadline(taskId, { deadline: editingDeadline.deadline });
      setEditingDeadline(null);
      // إعادة تحميل التقرير
      if (selectedReportProject) handleLoadReport(selectedReportProject);
      loadData();
      alert('Deadline updated!');
    } catch (err) {
      alert('Error updating deadline');
    }
  };

  const toggleProjectTasks = async (projectId) => {
    const isOpen = expandedTasks[projectId];
    setExpandedTasks(prev => ({ ...prev, [projectId]: !isOpen }));
    if (!isOpen && !projectTasks[projectId]) {
      try {
        const res = await getProjectTasks(projectId);
        setProjectTasks(prev => ({ ...prev, [projectId]: res.data }));
      } catch (err) {
        console.error('Error fetching project tasks', err);
      }
    }
  };

  const toggleScores = async (projectId) => {
    const isOpen = expandedScores[projectId];
    setExpandedScores(prev => ({ ...prev, [projectId]: !isOpen }));
    if (!isOpen && !projectScores[projectId]) {
      try {
        const res = await getProjectMembersScore(projectId);
        setProjectScores(prev => ({ ...prev, [projectId]: res.data }));
      } catch (err) {
        console.error('Error fetching scores', err);
      }
    }
  };

  const handleEditDescription = async (projectId) => {
    if (!editingProject || editingProject.project_id !== projectId) return;
    try {
      await updateProject(projectId, { description: editingProject.description });
      setEditingProject(null);
      loadData();
      alert('Description updated!');
    } catch (err) {
      alert('Error updating description');
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <div style={styles.container}>
      {/* Navbar */}
      <div style={styles.navbar}>
        <h2 style={styles.navTitle}>Smart Project</h2>
        <span style={styles.navName}> {name}</span>
        <button style={styles.logoutBtn} onClick={handleLogout}>Logout</button>
      </div>

      {/* Tabs */}
      <div style={styles.tabs}>
        {['projects', 'tasks', 'reports'].map(tab => (
          <button
            key={tab}
            style={activeTab === tab ? styles.activeTab : styles.tab}
            onClick={() => setActiveTab(tab)}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      <div style={styles.content}>

        {/* Projects Tab */}
        {activeTab === 'projects' && (
          <div>
            <h3>Create Project</h3>
            <form onSubmit={handleCreateProject} style={styles.form}>
              <input
                style={styles.input}
                placeholder="Project Name"
                value={newProject.name}
                onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
                required
              />
              <input
                style={styles.input}
                placeholder="Description"
                value={newProject.description}
                onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
              />
              <button style={styles.button} type="submit">Create</button>
            </form>

            <h3>My Projects</h3>
            {projects.length === 0 ? <p>No projects yet</p> :
              projects.map(p => (
                <div key={p.project_id} style={styles.card}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <h4 style={{ margin: 0 }}>{p.project_name}</h4>
                    <span style={styles.badge}>{p.status}</span>
                  </div>

                  {/* Description + Edit */}
                  {editingProject && editingProject.project_id === p.project_id ? (
                    <div style={{ marginTop: '10px' }}>
                      <textarea
                        style={{ ...styles.input, height: '80px', resize: 'vertical' }}
                        value={editingProject.description}
                        onChange={(e) => setEditingProject({ ...editingProject, description: e.target.value })}
                      />
                      <div style={{ display: 'flex', gap: '10px' }}>
                        <button style={styles.button} onClick={() => handleEditDescription(p.project_id)}>
                          💾 Save
                        </button>
                        <button style={styles.cancelBtn} onClick={() => setEditingProject(null)}>
                          ✖ Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div style={{ marginTop: '8px' }}>
                      <p style={{ color: '#555', marginBottom: '8px' }}>{p.description}</p>
                      <button
                        style={styles.editBtn}
                        onClick={() => setEditingProject({ project_id: p.project_id, description: p.description })}
                      >
                        ✏️ Edit Description
                      </button>
                    </div>
                  )}

                  {/* 🏆 Member Scores Toggle */}
                  <button
                    style={styles.scoresBtn}
                    onClick={() => toggleScores(p.project_id)}
                  >
                    🏆 {expandedScores[p.project_id] ? 'Hide' : 'Show'} Member Scores
                  </button>

                  {expandedScores[p.project_id] && (
                    <div style={styles.scoresPanel}>
                      <h4 style={styles.scoresPanelTitle}>📊 Member Performance — {p.project_name}</h4>
                      {!projectScores[p.project_id] ? (
                        <p style={{ color: '#888', fontSize: '13px' }}>Loading...</p>
                      ) : projectScores[p.project_id].length === 0 ? (
                        <p style={{ color: '#888', fontSize: '13px' }}>No members assigned to tasks in this project yet.</p>
                      ) : (
                        projectScores[p.project_id].map((m) => (
                          <div key={m.user_id} style={styles.scoreRow}>
                            {/* Rank Medal */}
                            <span style={styles.rankBadge}>
                              {m.rank === 1 ? '🥇' : m.rank === 2 ? '🥈' : m.rank === 3 ? '🥉' : `#${m.rank}`}
                            </span>

                            {/* Name & Stats */}
                            <div style={{ flex: 1 }}>
                              <div style={{ fontWeight: 600, fontSize: '14px' }}>{m.name}</div>
                              <div style={{ fontSize: '12px', color: '#666', marginTop: '2px' }}>
                                ✅ {m.completed}/{m.total_tasks} tasks &nbsp;|&nbsp;
                                🔄 {m.in_progress} in progress &nbsp;|&nbsp;
                                📈 Avg {m.avg_progress}%
                              </div>
                              {/* Score Bar */}
                              <div style={styles.scoreBarBg}>
                                <div style={{
                                  ...styles.scoreBarFill,
                                  width: `${m.score}%`,
                                  backgroundColor: m.score >= 75 ? '#4caf50' : m.score >= 40 ? '#ff9800' : '#f44336'
                                }} />
                              </div>
                            </div>

                            {/* Score % */}
                            <span style={{
                              ...styles.scorePercent,
                              color: m.score >= 75 ? '#2e7d32' : m.score >= 40 ? '#e65100' : '#c62828'
                            }}>
                              {m.score}%
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {/* 📁 Project Tasks Toggle */}
                  <button
                    style={styles.tasksToggleBtn}
                    onClick={() => toggleProjectTasks(p.project_id)}
                  >
                    📁 {expandedTasks[p.project_id] ? '▲ Hide' : '▼ Show'} Tasks
                    {projectTasks[p.project_id] ? ` (${projectTasks[p.project_id].length})` : ''}
                  </button>

                  {expandedTasks[p.project_id] && (
                    <div style={styles.tasksPanel}>
                      {!projectTasks[p.project_id] ? (
                        <p style={{ color: '#888', fontSize: '13px' }}>Loading...</p>
                      ) : projectTasks[p.project_id].length === 0 ? (
                        <p style={{ color: '#888', fontSize: '13px' }}>No tasks in this project yet.</p>
                      ) : (
                        projectTasks[p.project_id].map((t, i) => {
                          const statusColor = t.status === 'completed' ? '#4caf50'
                            : t.status === 'in_progress' ? '#ff9800' : '#9e9e9e';
                          return (
                            <div key={t.task_id} style={styles.taskItem}>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '6px' }}>
                                <div>
                                  <span style={{ fontWeight: 600, fontSize: '13px' }}>
                                    {i + 1}. {t.title}
                                  </span>
                                  {t.assigned_to_name && (
                                    <span style={styles.assignedTag}>👤 {t.assigned_to_name}</span>
                                  )}
                                </div>
                                <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                                  <span style={{ ...styles.statusChipSm, backgroundColor: statusColor }}>
                                    {t.status}
                                  </span>
                                  <span style={{ fontSize: '12px', color: '#888' }}>
                                    {'⭐'.repeat(t.complexity_level)}
                                  </span>
                                </div>
                              </div>
                              {t.description && (
                                <p style={{ fontSize: '12px', color: '#666', margin: '4px 0' }}>{t.description}</p>
                              )}
                              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '6px' }}>
                                <div style={{ flex: 1, backgroundColor: '#e0e0e0', borderRadius: '4px', height: '5px' }}>
                                  <div style={{ width: `${t.progress_percentage}%`, backgroundColor: '#1a73e8', height: '5px', borderRadius: '4px' }} />
                                </div>
                                <span style={{ fontSize: '12px', color: '#555', minWidth: '35px' }}>{t.progress_percentage}%</span>
                                {t.deadline && (
                                  <span style={{ fontSize: '12px', color: '#888' }}>
                                    📅 {new Date(t.deadline).toLocaleDateString()}
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  )}
                </div>
              ))
            }
          </div>
        )}

        {/* Tasks Tab */}
        {activeTab === 'tasks' && (
          <div>
            <h3>Create Task</h3>
            <form onSubmit={handleCreateTask} style={styles.form}>
              <input
                style={styles.input}
                placeholder="Task Title"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                required
              />
              <input
                style={styles.input}
                placeholder="Description"
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
              />
              <select
                style={styles.input}
                value={newTask.project_id}
                onChange={(e) => setNewTask({ ...newTask, project_id: e.target.value })}
                required
              >
                <option value="">Select Project</option>
                {projects.map(p => (
                  <option key={p.project_id} value={p.project_id}>{p.project_name}</option>
                ))}
              </select>
              <select
                style={styles.input}
                value={newTask.assigned_to}
                onChange={(e) => handleMemberSelect(e.target.value)}
                required
              >
                <option value="">Assign To</option>
                {users.filter(u => u.role === 'member').map(u => (
                  <option key={u.user_id} value={u.user_id}>{u.name}</option>
                ))}
              </select>

              {/* Deadline field */}
              <label style={{ fontSize: '13px', color: '#555', marginBottom: '4px', display: 'block' }}>Deadline</label>
              <input
                style={styles.input}
                type="date"
                value={newTask.deadline || ''}
                onChange={(e) => handleDeadlineChange(e.target.value)}
              />

              {/* ⚠️ Conflict Warning */}
              {conflicts.length > 0 && (
                <div style={styles.conflictBox}>
                  <strong>⚠️ Conflict Detected!</strong>
                  <p style={{ margin: '5px 0', fontSize: '13px' }}>
                    This member already has {conflicts.length} task(s) due on the same date:
                  </p>
                  {conflicts.map(c => (
                    <div key={c.task_id} style={styles.conflictItem}>
                      📌 <strong>{c.title}</strong> — {c.project_name} ({c.status})
                    </div>
                  ))}
                </div>
              )}

              {/* Member current tasks preview */}
              {memberTasks.length > 0 && (
                <div style={styles.memberTasksBox}>
                  <strong style={{ fontSize: '13px', color: '#1a73e8' }}>
                    📋 Current tasks for this member ({memberTasks.length}):
                  </strong>
                  {memberTasks.map(t => (
                    <div key={t.task_id} style={styles.memberTaskItem}>
                      <span style={{ fontWeight: 500 }}>{t.title}</span>
                      <span style={styles.memberTaskDeadline}>
                        {t.deadline ? `📅 ${new Date(t.deadline).toLocaleDateString()}` : 'No deadline'}
                      </span>
                      <span style={{
                        ...styles.statusDot,
                        backgroundColor: t.status === 'completed' ? '#4caf50' : t.status === 'in_progress' ? '#ff9800' : '#9e9e9e'
                      }}>
                        {t.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
              <select
                style={styles.input}
                value={newTask.complexity_level}
                onChange={(e) => setNewTask({ ...newTask, complexity_level: e.target.value })}
              >
                <option value="1">Low (1)</option>
                <option value="2">Medium-Low (2)</option>
                <option value="3">Medium (3)</option>
                <option value="4">Medium-High (4)</option>
                <option value="5">High (5)</option>
              </select>
              <button style={styles.button} type="submit">Create Task</button>
            </form>

            <h3>All Tasks</h3>
            {Array.isArray(tasks) && tasks.map(t => (
              <div key={t.task_id} style={styles.card}>
                <h4>{t.title}</h4>
                <p>{t.description}</p>
                <p>Progress: {t.progress_percentage}%</p>
                <div style={styles.progressBar}>
                  <div style={{ ...styles.progress, width: `${t.progress_percentage}%` }} />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Reports Tab */}
        {activeTab === 'reports' && (
          <div>

            {/* ── قسم ١: Team Performance ── */}
            <div style={styles.reportSection}>
              <h3 style={styles.reportTitle}>👥 Team Performance</h3>
              <div style={styles.reportGrid}>
                {Array.isArray(report) && report.map((r, i) => {
                  const score = parseInt(r.performance_score);
                  const color = score >= 75 ? '#2e7d32' : score >= 40 ? '#e65100' : '#c62828';
                  const bg    = score >= 75 ? '#e8f5e9' : score >= 40 ? '#fff3e0' : '#fce4ec';
                  return (
                    <div key={r.member_id} style={{ ...styles.reportCard, borderLeft: `4px solid ${color}` }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontWeight: 600, fontSize: '15px' }}>
                          {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`} {r.name}
                        </span>
                        <span style={{ ...styles.scorePill, backgroundColor: bg, color }}>
                          {r.performance_score}
                        </span>
                      </div>
                      <div style={styles.reportMeta}>
                        <span>📋 Total: {r.total_tasks}</span>
                        <span>✅ Done: {r.completed}</span>
                        <span>🔄 Active: {r.in_progress || 0}</span>
                      </div>
                      <div style={styles.reportBarBg}>
                        <div style={{ ...styles.reportBarFill, width: `${score}%`, backgroundColor: color }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ── قسم ٢: Project Report + Deadline Edit ── */}
            <div style={styles.reportSection}>
              <h3 style={styles.reportTitle}>📁 Project Report</h3>
              <div style={{ display: 'flex', gap: '10px', marginBottom: '16px', alignItems: 'center' }}>
                <select
                  style={{ ...styles.input, marginBottom: 0, flex: 1 }}
                  value={selectedReportProject}
                  onChange={(e) => {
                    setSelectedReportProject(e.target.value);
                    setProjectReport(null);
                  }}
                >
                  <option value="">— Select a Project —</option>
                  {projects.map(p => (
                    <option key={p.project_id} value={p.project_id}>{p.project_name}</option>
                  ))}
                </select>
                <button
                  style={styles.button}
                  onClick={() => handleLoadReport(selectedReportProject)}
                  disabled={!selectedReportProject}
                >
                  Load Report
                </button>
              </div>

              {projectReport && (
                <div>
                  {/* Summary Cards */}
                  <div style={styles.summaryRow}>
                    <div style={{ ...styles.summaryCard, borderTop: '3px solid #1a73e8' }}>
                      <div style={styles.summaryNum}>{projectReport.total_tasks}</div>
                      <div style={styles.summaryLabel}>Total Tasks</div>
                    </div>
                    <div style={{ ...styles.summaryCard, borderTop: '3px solid #4caf50' }}>
                      <div style={{ ...styles.summaryNum, color: '#2e7d32' }}>{projectReport.completed}</div>
                      <div style={styles.summaryLabel}>Completed</div>
                    </div>
                    <div style={{ ...styles.summaryCard, borderTop: '3px solid #ff9800' }}>
                      <div style={{ ...styles.summaryNum, color: '#e65100' }}>{projectReport.in_progress}</div>
                      <div style={styles.summaryLabel}>In Progress</div>
                    </div>
                    <div style={{ ...styles.summaryCard, borderTop: '3px solid #9e9e9e' }}>
                      <div style={{ ...styles.summaryNum, color: '#616161' }}>{projectReport.not_started}</div>
                      <div style={styles.summaryLabel}>Not Started</div>
                    </div>
                    <div style={{ ...styles.summaryCard, borderTop: '3px solid #7c4dff' }}>
                      <div style={{ ...styles.summaryNum, color: '#4527a0' }}>{projectReport.avg_progress}</div>
                      <div style={styles.summaryLabel}>Avg Progress</div>
                    </div>
                  </div>

                  {/* Tasks Table */}
                  <div style={styles.tableWrapper}>
                    <table style={styles.table}>
                      <thead>
                        <tr style={styles.tableHead}>
                          <th style={styles.th}>#</th>
                          <th style={styles.th}>Task</th>
                          <th style={styles.th}>Status</th>
                          <th style={styles.th}>Progress</th>
                          <th style={styles.th}>Complexity</th>
                          <th style={styles.th}>Deadline</th>
                          <th style={styles.th}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {projectReport.tasks.map((t, i) => {
                          const statusColor = t.status === 'completed' ? '#4caf50' : t.status === 'in_progress' ? '#ff9800' : '#9e9e9e';
                          const isEditing = editingDeadline && editingDeadline.task_id === t.task_id;
                          return (
                            <tr key={t.task_id} style={{ backgroundColor: i % 2 === 0 ? '#fafafa' : 'white' }}>
                              <td style={styles.td}>{i + 1}</td>
                              <td style={{ ...styles.td, fontWeight: 500 }}>{t.title}</td>
                              <td style={styles.td}>
                                <span style={{ ...styles.statusChip, backgroundColor: statusColor }}>
                                  {t.status}
                                </span>
                              </td>
                              <td style={styles.td}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                  <div style={{ ...styles.reportBarBg, flex: 1, margin: 0 }}>
                                    <div style={{ ...styles.reportBarFill, width: `${t.progress_percentage}%`, backgroundColor: '#1a73e8' }} />
                                  </div>
                                  <span style={{ fontSize: '12px', minWidth: '30px' }}>{t.progress_percentage}%</span>
                                </div>
                              </td>
                              <td style={{ ...styles.td, textAlign: 'center' }}>{'⭐'.repeat(t.complexity_level)}</td>
                              <td style={styles.td}>
                                {isEditing ? (
                                  <div style={{ display: 'flex', gap: '5px', alignItems: 'center' }}>
                                    <input
                                      type="date"
                                      value={editingDeadline.deadline}
                                      onChange={(e) => setEditingDeadline({ ...editingDeadline, deadline: e.target.value })}
                                      style={{ padding: '4px', borderRadius: '4px', border: '1px solid #ddd', fontSize: '12px' }}
                                    />
                                    <button style={styles.saveSmallBtn} onClick={() => handleUpdateDeadline(t.task_id)}>💾</button>
                                    <button style={styles.cancelSmallBtn} onClick={() => setEditingDeadline(null)}>✖</button>
                                  </div>
                                ) : (
                                  <span style={{ fontSize: '13px' }}>
                                    {t.deadline ? new Date(t.deadline).toLocaleDateString() : '—'}
                                  </span>
                                )}
                              </td>
                              <td style={styles.td}>
                                {!isEditing && (
                                  <button
                                    style={styles.extendBtn}
                                    onClick={() => setEditingDeadline({
                                      task_id: t.task_id,
                                      deadline: t.deadline ? t.deadline.split('T')[0] : ''
                                    })}
                                  >
                                    📅 Extend
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  container: { fontFamily: 'Arial, sans-serif', minHeight: '100vh', backgroundColor: '#f0f2f5' },
  navbar: { backgroundColor: '#1a73e8', padding: '15px 30px', display: 'flex', alignItems: 'center', gap: '20px' },
  navTitle: { color: 'white', margin: 0 },
  navName: { color: 'white', marginLeft: 'auto' },
  logoutBtn: { backgroundColor: 'white', color: '#1a73e8', border: 'none', padding: '8px 15px', borderRadius: '5px', cursor: 'pointer' },
  tabs: { display: 'flex', gap: '10px', padding: '20px 30px', backgroundColor: 'white', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' },
  tab: { padding: '10px 20px', border: '1px solid #ddd', borderRadius: '5px', cursor: 'pointer', backgroundColor: 'white' },
  activeTab: { padding: '10px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer', backgroundColor: '#1a73e8', color: 'white' },
  content: { padding: '30px' },
  form: { backgroundColor: 'white', padding: '20px', borderRadius: '10px', marginBottom: '20px' },
  input: { width: '100%', padding: '10px', marginBottom: '10px', borderRadius: '5px', border: '1px solid #ddd', fontSize: '14px', boxSizing: 'border-box' },
  button: { backgroundColor: '#1a73e8', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '5px', cursor: 'pointer' },
  card: { backgroundColor: 'white', padding: '15px', borderRadius: '10px', marginBottom: '10px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' },
  badge: { backgroundColor: '#e8f5e9', color: '#2e7d32', padding: '3px 10px', borderRadius: '10px', fontSize: '12px' },
  editBtn: { backgroundColor: '#fff3e0', color: '#e65100', border: '1px solid #ffcc80', padding: '5px 12px', borderRadius: '5px', cursor: 'pointer', fontSize: '13px' },
  cancelBtn: { backgroundColor: '#fce4ec', color: '#c62828', border: '1px solid #ef9a9a', padding: '8px 15px', borderRadius: '5px', cursor: 'pointer' },
  conflictBox: { backgroundColor: '#fff3e0', border: '1px solid #ff9800', borderRadius: '8px', padding: '12px', marginBottom: '12px' },
  conflictItem: { backgroundColor: '#ffe0b2', borderRadius: '5px', padding: '5px 10px', marginTop: '5px', fontSize: '13px' },
  memberTasksBox: { backgroundColor: '#e8f5e9', border: '1px solid #a5d6a7', borderRadius: '8px', padding: '12px', marginBottom: '12px' },
  memberTaskItem: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '5px 0', borderBottom: '1px solid #c8e6c9', fontSize: '13px', flexWrap: 'wrap', gap: '5px' },
  memberTaskDeadline: { color: '#555', fontSize: '12px' },
  statusDot: { color: 'white', padding: '2px 8px', borderRadius: '10px', fontSize: '11px' },
  scoresBtn: { marginTop: '12px', backgroundColor: '#e8eaf6', color: '#3949ab', border: '1px solid #9fa8da', padding: '6px 14px', borderRadius: '5px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 },
  tasksToggleBtn: { marginTop: '8px', marginLeft: '8px', backgroundColor: '#e8f5e9', color: '#2e7d32', border: '1px solid #a5d6a7', padding: '6px 14px', borderRadius: '5px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 },
  tasksPanel: { marginTop: '10px', backgroundColor: '#fafafa', borderRadius: '8px', padding: '10px', border: '1px solid #e8f5e9' },
  taskItem: { backgroundColor: 'white', borderRadius: '6px', padding: '10px 12px', marginBottom: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.06)', borderLeft: '3px solid #1a73e8' },
  assignedTag: { marginLeft: '8px', fontSize: '12px', color: '#555', backgroundColor: '#f5f5f5', padding: '1px 7px', borderRadius: '10px' },
  statusChipSm: { color: 'white', padding: '2px 7px', borderRadius: '8px', fontSize: '11px' },
  scoresPanel: { marginTop: '12px', backgroundColor: '#f5f5f5', borderRadius: '8px', padding: '12px', border: '1px solid #e0e0e0' },
  scoresPanelTitle: { margin: '0 0 10px 0', fontSize: '14px', color: '#333' },
  scoreRow: { display: 'flex', alignItems: 'center', gap: '12px', backgroundColor: 'white', borderRadius: '8px', padding: '10px 12px', marginBottom: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.07)' },
  rankBadge: { fontSize: '20px', minWidth: '30px', textAlign: 'center' },
  scoreBarBg: { backgroundColor: '#e0e0e0', borderRadius: '4px', height: '6px', marginTop: '5px' },
  scoreBarFill: { height: '6px', borderRadius: '4px', transition: 'width 0.3s ease' },
  scorePercent: { fontWeight: 700, fontSize: '15px', minWidth: '40px', textAlign: 'right' },
  // Report styles
  reportSection: { backgroundColor: 'white', borderRadius: '12px', padding: '20px', marginBottom: '20px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' },
  reportTitle: { margin: '0 0 16px 0', fontSize: '16px', color: '#333', borderBottom: '2px solid #f0f0f0', paddingBottom: '10px' },
  reportGrid: { display: 'flex', flexDirection: 'column', gap: '10px' },
  reportCard: { backgroundColor: '#fafafa', borderRadius: '8px', padding: '12px 16px', border: '1px solid #eee' },
  reportMeta: { display: 'flex', gap: '16px', marginTop: '8px', fontSize: '13px', color: '#666' },
  reportBarBg: { backgroundColor: '#e0e0e0', borderRadius: '4px', height: '5px', marginTop: '8px' },
  reportBarFill: { height: '5px', borderRadius: '4px', transition: 'width 0.3s' },
  scorePill: { padding: '3px 10px', borderRadius: '20px', fontSize: '13px', fontWeight: 600 },
  summaryRow: { display: 'flex', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' },
  summaryCard: { flex: 1, minWidth: '100px', backgroundColor: '#fafafa', borderRadius: '8px', padding: '14px', textAlign: 'center', border: '1px solid #eee' },
  summaryNum: { fontSize: '24px', fontWeight: 700, color: '#1a73e8' },
  summaryLabel: { fontSize: '12px', color: '#888', marginTop: '4px' },
  tableWrapper: { overflowX: 'auto', borderRadius: '8px', border: '1px solid #eee' },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: '13px' },
  tableHead: { backgroundColor: '#1a73e8' },
  th: { padding: '10px 12px', color: 'white', textAlign: 'left', fontWeight: 600, whiteSpace: 'nowrap' },
  td: { padding: '10px 12px', borderBottom: '1px solid #f0f0f0', verticalAlign: 'middle' },
  statusChip: { color: 'white', padding: '2px 8px', borderRadius: '10px', fontSize: '11px', whiteSpace: 'nowrap' },
  extendBtn: { backgroundColor: '#e3f2fd', color: '#1565c0', border: '1px solid #90caf9', padding: '4px 10px', borderRadius: '5px', cursor: 'pointer', fontSize: '12px', whiteSpace: 'nowrap' },
  saveSmallBtn: { backgroundColor: '#e8f5e9', color: '#2e7d32', border: '1px solid #a5d6a7', padding: '4px 8px', borderRadius: '4px', cursor: 'pointer' },
  cancelSmallBtn: { backgroundColor: '#fce4ec', color: '#c62828', border: '1px solid #ef9a9a', padding: '4px 8px', borderRadius: '4px', cursor: 'pointer' },
  scoresBtn: { marginTop: '10px', backgroundColor: '#ede7f6', color: '#4527a0', border: '1px solid #b39ddb', padding: '6px 14px', borderRadius: '5px', cursor: 'pointer', fontSize: '13px', width: '100%' },
  scoresPanel: { marginTop: '12px', backgroundColor: '#fafafa', border: '1px solid #e0e0e0', borderRadius: '8px', padding: '14px' },
  scoresPanelTitle: { margin: '0 0 12px 0', fontSize: '14px', color: '#333' },
  scoreRow: { display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 0', borderBottom: '1px solid #eeeeee' },
  rankBadge: { fontSize: '22px', minWidth: '36px', textAlign: 'center' },
  scoreBarBg: { backgroundColor: '#e0e0e0', borderRadius: '4px', height: '6px', marginTop: '5px' },
  scoreBarFill: { height: '6px', borderRadius: '4px', transition: 'width 0.4s ease' },
  scorePercent: { fontWeight: 700, fontSize: '16px', minWidth: '42px', textAlign: 'right' },
  progressBar: { backgroundColor: '#e0e0e0', borderRadius: '5px', height: '8px', marginTop: '5px' },
  progress: { backgroundColor: '#1a73e8', height: '8px', borderRadius: '5px' }
};

export default LeaderDashboard;
