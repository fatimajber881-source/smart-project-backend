require('dotenv').config();
const pool = require('../config/db');

// @route   GET /api/tasks
const getTasks = async (req, res) => {
  const { id, role } = req.user;

  try {
    let result;
    if (role === 'leader') {
      result = await pool.query(
        `SELECT t.*, ts.status_name 
         FROM tasks t
         JOIN task_statuses ts ON t.status_id = ts.status_id`
      );
    } else {
      result = await pool.query(
        `SELECT t.*, ts.status_name 
         FROM tasks t
         JOIN task_assignments ta ON t.task_id = ta.task_id
         JOIN task_statuses ts ON t.status_id = ts.status_id
         WHERE ta.assigned_to = $1 AND ta.is_active = true`, [id]
      );
    }

    if (result.rows.length === 0) {
      return res.json({ message: 'No tasks found' });
    }

    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @route   GET /api/tasks/:id
const getTaskById = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT t.*, ts.status_name
       FROM tasks t
       JOIN task_statuses ts ON t.status_id = ts.status_id
       WHERE t.task_id = $1`, [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Task not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @route   POST /api/tasks
const createTask = async (req, res) => {
  const { title, description, project_id, assigned_to, complexity_level, deadline } = req.body;

  if (!title || !project_id || !assigned_to) {
    return res.status(400).json({ message: 'Title, project_id, and assigned_to are required' });
  }

  try {
    const taskResult = await pool.query(
      `INSERT INTO tasks (title, description, project_id, created_by, complexity_level, deadline, status_id)
       VALUES ($1, $2, $3, $4, $5, $6, 1)
       RETURNING *`,
      [title, description || '', project_id, req.user.id, complexity_level || 3, deadline || null]
    );

    const task = taskResult.rows[0];

    await pool.query(
      `INSERT INTO task_assignments (task_id, assigned_to, assigned_by)
       VALUES ($1, $2, $3)`,
      [task.task_id, assigned_to, req.user.id]
    );

    // جيب اسم المشروع للـ notification
    const projectResult = await pool.query(
      `SELECT project_name FROM projects WHERE project_id = $1`,
      [project_id]
    );
    const projectName = projectResult.rows[0]?.project_name || 'a project';

    // ارسل notification للـ member
    await pool.query(
      `INSERT INTO notifications (user_id, task_id, title, message)
       VALUES ($1, $2, $3, $4)`,
      [
        assigned_to,
        task.task_id,
        `📌 New Task Assigned: ${title}`,
        `You have been assigned a new task "${title}" in project "${projectName}".${deadline ? ` Deadline: ${new Date(deadline).toLocaleDateString()}` : ''}`
      ]
    );

    res.status(201).json(task);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @route   PUT /api/tasks/:id/progress
const updateProgress = async (req, res) => {
  const { progress } = req.body;

  if (progress < 0 || progress > 100) {
    return res.status(400).json({ message: 'Progress must be between 0 and 100' });
  }

  try {
    let status_id = 1;
    if (progress > 0 && progress < 100) status_id = 2;
    if (progress === 100) status_id = 3;

    const result = await pool.query(
      `UPDATE tasks SET progress_percentage = $1, status_id = $2
       WHERE task_id = $3 RETURNING *`,
      [progress, status_id, req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Task not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @route   PUT /api/tasks/:id/time
const trackTime = async (req, res) => {
  const { action } = req.body;

  try {
    if (action === 'start') {
      await pool.query(
        `INSERT INTO time_logs (task_id, user_id, start_time)
         VALUES ($1, $2, NOW())`,
        [req.params.id, req.user.id]
      );
    } else if (action === 'stop') {
      await pool.query(
        `UPDATE time_logs 
         SET end_time = NOW(),
         duration_minutes = EXTRACT(EPOCH FROM (NOW() - start_time)) / 60
         WHERE task_id = $1 AND user_id = $2 AND end_time IS NULL`,
        [req.params.id, req.user.id]
      );
    } else {
      return res.status(400).json({ message: 'Action must be start or stop' });
    }

    res.json({ message: `Time ${action}ed successfully` });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @route   DELETE /api/tasks/:id
const deleteTask = async (req, res) => {
  try {
    const result = await pool.query(
      'DELETE FROM tasks WHERE task_id = $1 RETURNING *',
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Task not found' });
    }
    res.json({ message: 'Task deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @route   PUT /api/tasks/:id/deadline
const updateDeadline = async (req, res) => {
  const { deadline } = req.body;

  if (!deadline) {
    return res.status(400).json({ message: 'Deadline is required' });
  }

  try {
    const result = await pool.query(
      `UPDATE tasks SET deadline = $1 WHERE task_id = $2 RETURNING *`,
      [deadline, req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Task not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  getTasks,
  getTaskById,
  createTask,
  updateProgress,
  trackTime,
  updateDeadline,
  deleteTask
};